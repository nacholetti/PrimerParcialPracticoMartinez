
package recu;

public class Test {

    public static void main(String[] args) throws PlantaDuplicadExcepcion {
        
      JardinBotanico jardin = new JardinBotanico();
      
      Arbol arbolito = new Arbol(5, "Roble", "norte", "calor");
      Arbol arbolito2 = new Arbol(5, "pepa", "norte", "calor");      
      
      jardin.agregarPlanta(arbolito);
      jardin.agregarPlanta(arbolito2);
      jardin.mostrarPlantas();
        
    }
    
}
