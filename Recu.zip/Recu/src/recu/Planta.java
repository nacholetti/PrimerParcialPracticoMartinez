
package recu;

import java.util.Objects;


public abstract class Planta {
    
    private String nombre;
    private String ubicacion;
    private String clima;

    public Planta(String nombre, String ubicacion, String clima) {
        this.nombre = nombre;
        this.ubicacion = ubicacion;
        this.clima = clima;
    }
    
        @Override
    public int hashCode(){
        return Objects.hash(nombre,ubicacion);
    }
    
    
    @Override
    public boolean equals(Object obj){
        if (this == obj) {
            return true;
        }
        if (obj == null){
            return false;
        }
        if(obj instanceof Planta other ){
            return nombre.equals(other.nombre) && ubicacion.equals(other.ubicacion);
        }
        
        return false;
    }
    
    
    @Override
    public String toString() {
        return "Planta{" + "nombre=" + nombre + ", ubicacion=" + ubicacion + ", clima=" + clima + '}';
    }
    
    
   
    
}
