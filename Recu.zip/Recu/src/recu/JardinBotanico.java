
package recu;

import java.util.ArrayList;
import java.util.List;


public class JardinBotanico {
    
    private List<Planta> plantas;

    public JardinBotanico() {
         this.plantas = new ArrayList<>();
    }
    
    
    
    
    public void agregarPlanta(Planta planta) throws PlantaDuplicadExcepcion{
        if(this.plantas.contains(planta)){
            throw new PlantaDuplicadExcepcion();
        }
        this.plantas.add(planta);
    }
    
    
    public void mostrarPlantas(){
        for(Planta planta : plantas){
            System.out.println(planta);
        }
    }
    
   
    
}
