
package recu;


public interface Podable {
   
    public void podar();
}
