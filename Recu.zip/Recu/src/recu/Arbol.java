
package recu;


public class Arbol extends Planta implements Podable{
     public static final int ALTURA_MAXIMA = 10;
     
     private int altura;

    public Arbol(int altura, String nombre, String ubicacion, String clima) {
        super(nombre, ubicacion, clima);
        if(altura>ALTURA_MAXIMA){
            throw new IllegalArgumentException("Te pasaste de altura");
        }
        this.altura = altura;
    }

    @Override
    public String toString() {
        return super.toString(); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/OverriddenMethodBody
    }

    
    
    
    
    
    @Override
    public void podar() {
        System.out.println("Arbol podado...");
    }
     
     
     
}
