
package recu;


public class Arbusto extends Planta implements Podable{
    public static final int FOLLAJEMAXIMA = 10;
    public static final int FOLLAJEMINIMA = 1;
    private int follaje;

    public Arbusto(int follaje, String nombre, String ubicacion, String clima) {
        super(nombre, ubicacion, clima);
        
        if(follaje>FOLLAJEMAXIMA || follaje<FOLLAJEMINIMA){
            throw new IllegalArgumentException("Te pasaste o te falta follaje pa");
        }
        this.follaje = follaje;
    }

    @Override
    public String toString() {
        return "Arbusto{" + "follaje=" + follaje + '}';
    }

    
    
    @Override
    public void podar() {
        System.out.println("Arbusto podado...");
    }
    
    
    
    

}
