
package recu;


public class PlantaDuplicadExcepcion extends Exception {
    
    
     public PlantaDuplicadExcepcion() {
        super("Planta duplicada");
    }
   
    
}
